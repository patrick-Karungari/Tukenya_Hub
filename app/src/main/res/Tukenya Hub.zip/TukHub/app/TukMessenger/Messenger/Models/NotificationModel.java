package com.patrickarungari.tukenyahub.TukMessenger.Messenger.Models;


/*
NotificationType:
 1) Friend Request



 */


public class NotificationModel {


    public String NotificationMessage;
    public int NotificationType;
    public String EmailFrom;

    public String FirstName;
    public String LastName;

    public String FriendRequestFireBaseKey;

}
