package com.patrickarungari.tukenyahub.TukMessenger.Messenger.Models;


public class User {

    public String Password;


    public long ID;
    public String Email;
    public String FirstName;
    public String LastName;
    public String EntryDate;


}
