package com.patrickarungari.tukenyahub.TukMessenger.Messenger.Models;


public class Message {

    public String FromMail;
    public String ToMail;
    public String Message;
    public String SentDate;
    public String FriendFullName;

    public int rowid;
}
