package com.patrickarungari.tukenyahub.TukMessenger.Messenger;

import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.patrickarungari.tukenyahub.R;
import com.patrickarungari.tukenyahub.TukMessenger.Messenger.Models.NotificationModel;
import com.patrickarungari.tukenyahub.TukMessenger.Messenger.Models.StaticInfo;
import com.patrickarungari.tukenyahub.TukMessenger.Messenger.Models.User;
import com.patrickarungari.tukenyahub.TukMessenger.Messenger.Services.LocalUserService;
import com.patrickarungari.tukenyahub.TukMessenger.Messenger.Services.Tools;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ActivityNotifications extends AppCompatActivity {

    ListView lv_NotificationList;
    User user;
    List<NotificationModel> notificationList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
        //Firebase.setAndroidContext(this);
    }

    @Override
    protected void onStart() {
        super.onStart();

        lv_NotificationList = (ListView) findViewById(R.id.lv_NoticicationList);
        notificationList = new ArrayList<>();
        user = LocalUserService.getLocalUserFromPreferences(this);
        DatabaseReference reqRef = FirebaseDatabase.getInstance().getReference(StaticInfo.EndPoint + "/friendrequests/" + user.Email);
        reqRef.addChildEventListener(
                new ChildEventListener() {
                    @Override
                    public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                        Map map = dataSnapshot.getValue(Map.class);
                        String firstName = map.get("FirstName").toString();
                        String lastName = map.get("LastName").toString();
                        final String key = dataSnapshot.getKey();
                        NotificationModel not = new NotificationModel();
                        not.FirstName = firstName;
                        not.LastName = lastName;
                        not.NotificationType = 1; // friend request
                        notificationList.add(not);
                        not.EmailFrom = key;
                        not.FriendRequestFireBaseKey = dataSnapshot.getKey();
                        not.NotificationMessage = Tools.toProperName(firstName) + " " + Tools.toProperName(lastName);
                        ListAdapter adp = new NotficationListAdapter(ActivityNotifications.this, notificationList);
                        lv_NotificationList.setAdapter(adp);
                    }

                    @Override
                    public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                    }

                    @Override
                    public void onChildRemoved(DataSnapshot dataSnapshot) {
                        String friendEmail = dataSnapshot.getKey();
                        int index = -1;
                        for (int i = 0; i < notificationList.size(); i++) {
                            NotificationModel item = notificationList.get(i);
                            if (item.EmailFrom.equals(friendEmail))
                                index = i;
                        }
                        notificationList.remove(index);
                        ListAdapter adp = new NotficationListAdapter(ActivityNotifications.this, notificationList);
                        lv_NotificationList.setAdapter(adp);

                    }

                    @Override
                    public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }


                }
        );


    }

}
