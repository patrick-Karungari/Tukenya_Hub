package com.patrickarungari.tukenyahub.TukMessenger.Messenger;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.patrickarungari.tukenyahub.R;
import com.patrickarungari.tukenyahub.TukMessenger.Messenger.Models.User;
import com.patrickarungari.tukenyahub.TukMessenger.Messenger.Services.DataContext;
import com.patrickarungari.tukenyahub.TukMessenger.Messenger.Services.LocalUserService;
import com.patrickarungari.tukenyahub.TukMessenger.Messenger.Services.Tools;


public class ActivityProfile extends AppCompatActivity {

    DataContext db = new DataContext(this, null, null, 1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        User user = LocalUserService.getLocalUserFromPreferences(this);
        TextView tv_UserFullName = (TextView) findViewById(R.id.tv_UserFullName);
        tv_UserFullName.setText(Tools.toProperName(user.FirstName) + " " + Tools.toProperName(user.LastName));
    }
}
