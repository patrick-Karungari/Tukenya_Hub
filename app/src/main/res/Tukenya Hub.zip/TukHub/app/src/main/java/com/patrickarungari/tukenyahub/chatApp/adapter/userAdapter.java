package com.patrickarungari.tukenyahub.chatApp.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.patrickarungari.tukenyahub.Modules.animation;
import com.patrickarungari.tukenyahub.R;
import com.patrickarungari.tukenyahub.chatApp.PersonChatActivity;
import com.patrickarungari.tukenyahub.chatApp.utils.DataContext;

import java.util.List;


public class userAdapter extends RecyclerView.Adapter<userAdapter.ViewHolder> {
    private Context ctx;
    private List<User> users;
    private DataContext db = new DataContext();

    public userAdapter(Context context, List<User> users) {
        this.ctx = context;
        this.users = users;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.user_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        User user = users.get(position);
        holder.tusername.setText(user.getUsername());
        String url = user.getImagePath();
        Glide.with(ctx.getApplicationContext()).load(url)
                .circleCrop()
                .into(holder.imageView);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ctx, PersonChatActivity.class);
                intent.putExtra("user",user.getUsername());
                intent.putExtra("id",user.getId());
                intent.putExtra("image",user.getImagePath());
                ctx.startActivity(intent);
                animation.slideUp(ctx);
            }
        });
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (users.size() <= position) return false;
                // final Message selectedMessageItem = userLastChatList.get(position);
                final CharSequence[] options = new CharSequence[]{"Delete Friend"};
                AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                builder.setTitle(user.getUsername());
                builder.setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int index) {
                        // the user clicked on list[index]
                        if (index == 0) {
                            // Delete Chat
                            new AlertDialog.Builder(ctx)
                                    .setTitle(user.getUsername())
                                    .setMessage("Are you sure to delete this Friend?")
                                    .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            db.deleteFriend(user.getId());
                                            Toast.makeText(ctx, "Friend deleted successfully", Toast.LENGTH_SHORT).show();
                                            notifyDataSetChanged();
                                        }
                                    })
                                    .setNegativeButton(android.R.string.no, null)
                                    .show();
                        }
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tusername;
        public ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tusername = itemView.findViewById(R.id.username);
            imageView = itemView.findViewById(R.id.profile_pic);
        }
    }
}
