package com.patrickarungari.tukenyahub.chatApp.fragments;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.patrickarungari.tukenyahub.R;
import com.patrickarungari.tukenyahub.chatApp.adapter.User;
import com.patrickarungari.tukenyahub.chatApp.adapter.chatsAdapter;
import com.patrickarungari.tukenyahub.chatApp.ui.main.PageViewModel;

import com.patrickarungari.messenger.ui.ChatUI;

import java.util.List;

import static com.patrickarungari.messenger.ui.chat_groups.fragments.BottomSheetGroupAdminPanelMember.TAG;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ChatFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ChatFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "section_number";
    private ShimmerFrameLayout containerView;
    private PageViewModel pageViewModel;
    RecyclerView recyclerView;
    chatsAdapter userAdapter;
    List<User> mUsers;
    List<String> usersList;
    private Context context;
    private FloatingActionButton addNewConversation;


    public ChatFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static ChatFragment newInstance(int index) {
        ChatFragment fragment = new ChatFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, index);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pageViewModel = new ViewModelProvider(this).get(PageViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            index = getArguments().getInt(ARG_SECTION_NUMBER);
        }
        pageViewModel.setIndex(index);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_chat, container, false);
        setHasOptionsMenu(false); // disable fragment option menu
        addNewConversation = view.findViewById(R.id.new_chat);
        setAddNewConversationClickBehaviour();
        // starts the chat inside a container
        ChatUI.getInstance().openConversationsListFragment(getChildFragmentManager(), R.id.container);

        return view;
    }

    private void setAddNewConversationClickBehaviour() {
        Log.d(TAG, "ConversationListFragment.setAddNewConversationClickBehaviour");

        addNewConversation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ChatUI.getInstance().getOnNewConversationClickListener() != null) {
                    ChatUI.getInstance().getOnNewConversationClickListener().onNewConversationClicked();
                }
            }
        });
    }

  /*  @Override
    public void onResume() {
        super.onResume();
       //containerView.startShimmer();
        new getUsersTask(ChatFragment.this).execute();
    }

    @Override
    public void onStart() {
        super.onStart();
        new getUsersTask(ChatFragment.this).execute();
    }

    private synchronized void readusers() {
        usersList = new ArrayList<>();
        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Chats").child(firebaseUser.getUid());
        databaseReference.keepSynced(true);
        databaseReference.push();
        String key = databaseReference.getKey();
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                usersList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    String receiver = (String) dataSnapshot.getKey();
                    usersList.add(receiver);
                }
                readChats();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    synchronized private void  readChats() {
        mUsers = new ArrayList<>();
        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("users");
        databaseReference.keepSynced(true);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                mUsers.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    String name = (String) dataSnapshot.child("Name").getValue();
                    String num = (String) dataSnapshot.child("regNum").getValue();
                    String path = (String) dataSnapshot.child("imagePath").getValue();
                    String userId = (String) dataSnapshot.child("id").getValue();
                    assert firebaseUser != null;

                    User users = new User(num, userId, path, name);

                   for(String id : usersList){
                       if(users.getId().equals(id)){
                           mUsers.add(users);
                       }
                   }
                }
                containerView.stopShimmer();
                containerView.setVisibility(View.GONE);
                userAdapter = new chatsAdapter(context, mUsers);
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
                if(userAdapter != null){
                    recyclerView.addItemDecoration(
                            new HorizontalDividerItemDecoration.Builder(context)
                                    .color(ContextCompat.getColor(context,R.color.background))
                                    .sizeResId(R.dimen.divider)
                                    .marginResId(R.dimen.leftmargin, R.dimen.rightmargin)
                                    .build());
                }
                recyclerView.setAdapter(userAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    @Override
    public void onPause() {
        containerView.stopShimmer();
        super.onPause();
    }

    private static class getUsersTask extends AsyncTask<Void,Void,Void> {

        // only retain a weak reference to the activity
        ChatFragment  activity;
        public getUsersTask(ChatFragment context) {
            WeakReference<ChatFragment> activityReference = new WeakReference<>(context);
            activity = activityReference.get();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            activity.readusers();
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            activity.containerView.setVisibility(View.GONE);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            activity.containerView.stopShimmer();
        }
    }
*/
}