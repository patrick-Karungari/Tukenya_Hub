package com.patrickarungari.tukenyahub.chatApp.Messenger;

public class ActivityProfile {
}
