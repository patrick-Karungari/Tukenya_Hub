package com.patrickarungari.tukenyahub.chatApp.adapter;

public class User {

    private String regNum;

    private String imagePath;

    private String Name;
    private String id;

    public User() {
    }

    public User(String regNum, String id, String imagePath, String name) {
        this.regNum = regNum;
        this.imagePath = imagePath;
        this.Name = name;
        this.id = id;
    }




    public String getUsername() {
        return this.Name;
    }


    public String getImagePath() {
        return this.imagePath;
    }

    public String getUniNum() {
        return this.regNum;
    }

    public String getId() {
        return id;
    }

    public void setRegNum(String regNum) {
        this.regNum = regNum;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setId(String id) {
        this.id = id;
    }
}
