package com.patrickarungari.tukenyahub.Activities;

import android.animation.Animator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.patrickarungari.tukenyahub.Modules.ScreenRotation;
import com.patrickarungari.tukenyahub.R;

import spencerstudios.com.bungeelib.Bungee;

public class SplashScreen extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        new ScreenRotation(getApplicationContext(), this);
        setTheme(R.style.BrandedLaunch);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.load);
        int SPLASH_TIME_OUT = 3000;
        new Handler().postDelayed(new Runnable() {
            /*
             * Showing splash screen with a timer. This will be useful when you
             * want to show case your app logo / company
             */

            @Override
            public void run() {
                // This method will be executed once the timer is over
                // Start your app main activity
                LottieAnimationView animationView = findViewById(R.id.animation_view);
                animationView.addAnimatorListener(new Animator.AnimatorListener() {
                    @Override
                    public void onAnimationStart(Animator animation) {
                        Toast.makeText(SplashScreen.this, "Animation Started", Toast.LENGTH_LONG).show();
                    }


                    @Override
                    public void onAnimationEnd(Animator animation) {
                        Intent i = new Intent(SplashScreen.this, MainActivity.class);
                        startActivity(i);
                        Bungee.zoom(SplashScreen.this);
                        // close this activity
                        finish();
                    }

                    @Override
                    public void onAnimationCancel(Animator animation) {

                    }

                    @Override
                    public void onAnimationRepeat(Animator animation) {

                    }
                });

            }
        }, SPLASH_TIME_OUT);
    }
}
