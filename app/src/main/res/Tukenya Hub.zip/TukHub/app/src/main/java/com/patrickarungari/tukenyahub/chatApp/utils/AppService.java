package com.patrickarungari.tukenyahub.chatApp.utils;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.patrickarungari.tukenyahub.R;
import com.patrickarungari.tukenyahub.chatApp.Messenger.ActivityNotifications;
import com.patrickarungari.tukenyahub.chatApp.PersonChatActivity;
import com.patrickarungari.tukenyahub.chatApp.adapter.User;

public class AppService extends Service {
    public AppService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // FirebaseDatabase.setAndroidContext(getApplicationContext());
        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference(StaticInfo.NotificationEndPoint + "/" + FirebaseAuth.getInstance().getCurrentUser().getUid());
        reference.addChildEventListener(
                new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, String s) {
                        if (dataSnapshot.getValue() != null) {
                            //Map map = dataSnapshot.getValue(Map.class);
                            String mess = dataSnapshot.child("message").getValue().toString();
                            String senderID = dataSnapshot.child("id").getValue().toString();
                            String senderFullName = Tools.toProperName(dataSnapshot.child("receiver").getValue().toString());
                            int notificationType = 1; // Message
                            //notificationType = map.get("NotificationType") == null ? 1 : Integer.parseInt(map.get("NotificationType").toString());
                            // check if user is on chat activity with senderEmail
                            if (!StaticInfo.UserCurrentChatFriendEmail.equals(senderID)) {
                                notifyUser(senderID, senderFullName, mess, notificationType);
                                // remove notification
                            }
                            reference.child(dataSnapshot.getKey()).removeValue();
                        }


                    }

                    @Override
                    public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                    }

                    @Override
                    public void onChildRemoved(DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }


                }
        );
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // check if user is login

        sendBroadcast(new Intent("com.patrickarungari.tukenyahub.TukMessenger.restartservice"));


    }

    private void notifyUser(String friendID, String senderFullName, String mess, int notificationType) {



            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("users");
            reference.keepSynced(true);
            reference.child(friendID).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if (dataSnapshot.getValue() != null) {
                        String name = (String) dataSnapshot.child("Name").getValue();
                        String num = (String) dataSnapshot.child("regNum").getValue();
                        String path = (String) dataSnapshot.child("imagePath").getValue();
                        String userId = (String) dataSnapshot.getKey();
                        User frnd = new User(num, userId, path, name);
                        popNotification(frnd,mess,senderFullName,friendID,notificationType);
                    }


                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
           // User frnd = DataContext.getFriendByEmail(friendID);

        }



    private void popNotification(User frnd, String mess, String senderFullName, String friendID, int notificationType) {
        NotificationCompat.Builder not = new NotificationCompat.Builder(getApplicationContext(), "messages");
        not.setAutoCancel(true);
        not.setSmallIcon(R.drawable.ic_message);
        not.setTicker("New Message");
        not.setWhen(System.currentTimeMillis());
        not.setContentText(mess);


        Intent i;
        // 1) Message 3) Contact Request Accepted
        if (notificationType == 1 || notificationType == 3) {
            i = new Intent(getApplicationContext(), PersonChatActivity.class);
            if (frnd.getUsername() != null) {
                not.setContentTitle(frnd.getUsername());
                i.putExtra("FriendFullName", frnd.getUsername());
            } else {
                not.setContentTitle(senderFullName);
                i.putExtra("FriendFullName", senderFullName);
            }
        }// Contact Request
        else if (notificationType == 2) {
            i = new Intent(getApplicationContext(), ActivityNotifications.class);
            not.setContentTitle(senderFullName);
        } else {
            i = null;
        }
        Glide.with(this)
                .asBitmap()
                .load(frnd.getImagePath())
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        not.setLargeIcon(resource);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                    }
                });
        if (i != null) {
            i.putExtra("FriendEmail", friendID);
        }
        int uniqueID = Tools.createUniqueIdPerUser(friendID);
        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), uniqueID, i, PendingIntent.FLAG_UPDATE_CURRENT);
        not.setContentIntent(pendingIntent);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Messages";
            String description = "Chat messages";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("messages", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            //NotificationManager notificationManager = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
        not.setDefaults(Notification.DEFAULT_ALL);
        nm.notify(uniqueID, not.build());

    }
}
