package com.patrickarungari.tukenyahub.utils;

public interface firebase {
    void onCallback(String value);
}
