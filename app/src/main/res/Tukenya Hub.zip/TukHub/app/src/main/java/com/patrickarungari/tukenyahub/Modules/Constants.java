package com.patrickarungari.tukenyahub.Modules;

/**
 * Created by Patrick Karungari on 15/03/2020.
 */

public class Constants {

    public static final String ROOT_URL = "https://c4cce209841f.ngrok.io/TukenyaHub/v1/";
    public static final String URL_REGISTER = "registerUser.php";
    public static final String URL_LOGIN = "userLogin.php";


}
