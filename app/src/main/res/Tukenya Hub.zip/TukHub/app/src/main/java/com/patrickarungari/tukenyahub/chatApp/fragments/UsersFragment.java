package com.patrickarungari.tukenyahub.chatApp.fragments;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.patrickarungari.tukenyahub.R;
import com.patrickarungari.tukenyahub.chatApp.adapter.User;
import com.patrickarungari.tukenyahub.chatApp.adapter.userAdapter;
import com.patrickarungari.tukenyahub.chatApp.ui.main.PageViewModel;
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link UsersFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class UsersFragment extends Fragment{

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_SECTION_NUMBER = "section_number";
    private ShimmerFrameLayout containerView;
    private PageViewModel pageViewModel;
    RecyclerView recyclerView;
    userAdapter userAdapter;
    List<User> mUser;
    private Context context;
    // TODO: Rename and change types of parameters


    public UsersFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static UsersFragment newInstance(int index) {
        UsersFragment fragment = new UsersFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, index);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        pageViewModel = new ViewModelProvider(this).get(PageViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            index = getArguments().getInt(ARG_SECTION_NUMBER);
        }
        pageViewModel.setIndex(index);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mUser = new ArrayList<>();
        View view = inflater.inflate(R.layout.fragment_users, container, false);
        containerView =
                view.findViewById(R.id.shimmer_view_container);
        recyclerView = view.findViewById(R.id.recycler_view);

        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onResume() {
        super.onResume();
        //new getUsersTask(UsersFragment.this).execute();
    }

    @Override
    public void onStart() {
        super.onStart();
        new getUsersTask(UsersFragment.this).execute();
    }

    @Override
    public void onPause() {
        super.onPause();
        containerView.stopShimmer();
        containerView.setVisibility(View.GONE);
    }

    private static class getUsersTask extends AsyncTask<Void,Void,Void> {

        // only retain a weak reference to the activity
        UsersFragment  activity;
        public getUsersTask(UsersFragment context) {
            WeakReference<UsersFragment> activityReference = new WeakReference<>(context);
            activity = activityReference.get();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            activity.readusers();
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            activity.containerView.setVisibility(View.GONE);
           // activity.containerView.startShimmer();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            activity.containerView.stopShimmer();
        }
    }

    private void readusers() {
        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("users");
        databaseReference.keepSynced(true);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                mUser.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    if (dataSnapshot != null && firebaseUser!=null ){
                        String name = (String) dataSnapshot.child("Name").getValue();
                        String num = (String) dataSnapshot.child("regNum").getValue();
                        String path = (String) dataSnapshot.child("imagePath").getValue();
                        String userId = (String) dataSnapshot.getKey();
                        String user = firebaseUser.getUid();
                        User users = new User(num, userId, path, name);
                        String Uid = users.getId();
                        if ( !Uid.isEmpty() && !Uid.equals(user)) {
                            mUser.add(users);
                        }
                    }

                }

                userAdapter = new userAdapter(context, mUser);
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
                if(userAdapter != null){
                    recyclerView.addItemDecoration(
                            new HorizontalDividerItemDecoration.Builder(context)
                                    .color(ContextCompat.getColor(context,R.color.background))
                                    .sizeResId(R.dimen.divider)
                                    .marginResId(R.dimen.leftmargin, R.dimen.rightmargin)
                                    .build());
                }
                recyclerView.setAdapter(userAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}