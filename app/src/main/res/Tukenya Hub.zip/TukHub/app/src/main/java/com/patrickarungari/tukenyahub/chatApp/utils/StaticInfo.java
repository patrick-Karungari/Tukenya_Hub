package com.patrickarungari.tukenyahub.chatApp.utils;


public class StaticInfo {

    public static String EndPoint = "https://mys3chat.firebaseio.com";
    public static String MessagesEndPoint = "messages";
    public static String FriendsURL = "friends";
    public static String UsersURL = "Users";
    public static String UserCurrentChatFriendEmail = "";
    public static String TypingStatus = "TypingStatus";

    public static String NotificationEndPoint = "notifications";
    public static String FriendRequestsEndPoint = "friendrequests";

    public static int ChatAciviityRequestCode = 101;

}
