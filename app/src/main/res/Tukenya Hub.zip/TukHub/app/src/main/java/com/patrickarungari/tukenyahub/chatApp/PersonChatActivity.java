package com.patrickarungari.tukenyahub.chatApp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import com.patrickarungari.tukenyahub.Modules.animation;
import com.patrickarungari.tukenyahub.R;
import com.patrickarungari.tukenyahub.chatApp.Messenger.MessengerMain;
import com.patrickarungari.tukenyahub.chatApp.adapter.MessageAdapter;
import com.patrickarungari.tukenyahub.chatApp.adapter.Messages;
import com.patrickarungari.tukenyahub.chatApp.utils.StaticInfo;
import com.patrickarungari.tukenyahub.chatApp.utils.Tools;
import com.patrickarungari.tukenyahub.databinding.ActivityPersonChatBinding;
import com.patrickarungari.tukenyahub.utils.MaterialEmojiLayoutFactory;
import com.vanniktech.emoji.EmojiPopup;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PersonChatActivity extends AppCompatActivity {
    private static final String TAG = "Person Activity: ";
    @BindView(R.id.pic_profile)
    ImageView profile_pic;
    @BindView(R.id.username)
    TextView username;
    @BindView(R.id.last_seen)
    TextView lastseen;
    Intent intent;
    private EditText mEditText;
    private FirebaseUser firebaseUser;
    private String senderId, receiver;
    private String last_seen, key;
    private Calendar calendar;
    private FirebaseDatabase database;
    DatabaseReference reference;
    private MessageAdapter messageAdapter;
    private List<Messages> messageReceived, messageSent;
    ValueEventListener seenMessage;
    RecyclerView recyclerView;
    private ArrayList<Messages> list;
    private ActivityPersonChatBinding mBinding;
    EmojiPopup emojiPopup;
    private DatabaseReference lastOnlineRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getLayoutInflater().setFactory2(new MaterialEmojiLayoutFactory((LayoutInflater.Factory2) getDelegate()));
        super.onCreate(savedInstanceState);
        mBinding = ActivityPersonChatBinding.inflate(getLayoutInflater());
        setContentView(mBinding.getRoot());
        //setContentView(R.layout.activity_person_chat);
        ButterKnife.bind(this);
        initUi();
    }

    private void initUi() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        messageSent = new ArrayList<>();
        messageReceived = new ArrayList<>();
        recyclerView = findViewById(R.id.container);
        calendar = Calendar.getInstance();
        database = FirebaseDatabase.getInstance();
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        assert firebaseUser != null;
        senderId = firebaseUser.getUid();
        intent = getIntent();
        Glide.with(this).load(intent.getStringExtra("image"))
                .circleCrop()
                .into(profile_pic);
        receiver = intent.getStringExtra("id");
        username.setText(intent.getStringExtra("user"));
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        // mContainer = (LinearLayout) findViewById(R.id.container);
        // mEditText = (EditText) findViewById(R.id.whatsapp_edit_view);
        findViewById(R.id.send_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!mBinding.send.whatsappEditView.getText().toString().isEmpty()) {
                    String text = mBinding.send.whatsappEditView.getText().toString().trim();
                    addView(text);

                }
            }
        });
        prepareChat();
        list = new ArrayList();
        messageAdapter = new MessageAdapter(PersonChatActivity.this);
        recyclerView.setAdapter(messageAdapter);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        reference = database.getReference("users").child(firebaseUser.getUid()).child("lastSeen");
        mBinding.send.emojiBtn.setOnClickListener(ignore -> emojiPopup.toggle());
        setUpEmojiPopup();
    }

    private void prepareChat() {
        getmessagesReceived();

    }

    public void seenMessage(String senderId, String receiver, String key) {
        DatabaseReference reference = database.getReference("Chats/" + receiver + "/" + senderId);
        reference.keepSynced(true);

        if (StaticInfo.UserCurrentChatFriendEmail.equals(receiver)) {
            HashMap<String, Object> hashMap = new HashMap<String, Object>();
            hashMap.put("read", true);
            reference.getRef().child(reference.push().getKey()).updateChildren(hashMap);
        }


    }

    @Override
    protected void onStart() {
        super.onStart();
        seenMessage(senderId, receiver, key);
        // Retrieve the timestamp of users' last disconnect (the last time they were seen online)
        lastOnlineRef = database.getReference("users").child(receiver).child("lastSeen");
        lastOnlineRef.keepSynced(true);
        lastOnlineRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.getValue() == null) {
                    last_seen = null;
                } else {
                    if (!snapshot.getValue().equals("Online") && !snapshot.getValue().equals("Typing ...")) {
                        long time = Long.parseLong(snapshot.getValue().toString());
                        if (isToday(time)) {
                            calendar.setTimeInMillis(time);
                            SimpleDateFormat output = new SimpleDateFormat("HH:mm", Locale.getDefault());
                            last_seen = output.format(new Date(time));
                            lastseen.setText(MessageFormat.format("Last seen today at {0}", last_seen));
                        } else if (isYesterday(time)) {
                            calendar.setTimeInMillis(time);
                            //DateFormat outputformat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
                            SimpleDateFormat output = new SimpleDateFormat("HH:mm", Locale.getDefault());
                            last_seen = output.format(new Date(time));
                            lastseen.setText(MessageFormat.format("Last seen yesterday at {0}", last_seen));
                        } else {
                            calendar.setTimeInMillis(time);
                            SimpleDateFormat output = new SimpleDateFormat("dd, MM-yy HH:mm", Locale.getDefault());
                            last_seen = output.format(new Date(time));
                            lastseen.setText(last_seen);
                        }

                    } else {
                        if (Tools.isNetworkAvailable(getApplicationContext())) {
                            lastseen.setText(snapshot.getValue().toString());
                        } else lastseen.setText("");

                    }

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
        if (last_seen == null) {
            lastseen.setText("");
        }
        StaticInfo.UserCurrentChatFriendEmail = receiver;

        mBinding.send.whatsappEditView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                reference.setValue("Typing ...");
                if (mBinding.send.whatsappEditView.getText().toString().length() == 0) {
                    reference.setValue("Typing ...");
                } else if (mBinding.send.whatsappEditView.getText().toString().length() >= 1) {
                    reference.setValue("Typing ...");
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void setUpEmojiPopup() {
        emojiPopup = EmojiPopup.Builder.fromRootView(mBinding.getRoot())
                .setIconColor(ContextCompat.getColor(this, R.color.emoji_gray70))
                .setBackgroundColor(ContextCompat.getColor(this, R.color.grey_300))
                .setOnEmojiBackspaceClickListener(ignore ->
                        Log.d(TAG, "Clicked on Backspace"))
                .setOnEmojiClickListener((ignore, ignore2) -> Log.d(TAG, "Clicked on emoji"))
                .setOnEmojiPopupShownListener(() -> mBinding.send.emojiBtn.setImageResource(R.drawable.ic_keyboard))
                .setOnSoftKeyboardOpenListener(ignore -> Log.d(TAG, "Opened soft keyboard"))
                .setOnEmojiPopupDismissListener(() -> mBinding.send.emojiBtn.setImageResource(R.drawable.emoji_ios_category_smileysandpeople))
                .setOnSoftKeyboardCloseListener(() -> {
                    Log.d(TAG, "Closed soft keyboard");
                    reference.setValue("Online");
                })
                .setKeyboardAnimationStyle(R.style.emoji_slide_animation_style)
                .setPageTransformer((page, position) -> {
                })
                .build(mBinding.send.whatsappEditView);
    }

    private void getmessagesReceived() {
        DatabaseReference reference = database.getReference("Chats");
        reference.keepSynced(true);
        reference.child(senderId).child(receiver).push();
        reference.child(senderId).child(receiver).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                messageAdapter.clearAllMessage();
                if (snapshot.getValue() != null) {
                    String message = (String) snapshot.child("message").getValue();
                    long time = (Long) snapshot.child("time").getValue();
                    String senderId = (String) snapshot.child("id").getValue();
                    String receiverId = (String) snapshot.child("receiver").getValue();
                    assert firebaseUser != null;
                    //String user = firebaseUser.getUid();
                    boolean read = (boolean) snapshot.child("read").getValue();
                    key = snapshot.getKey();
                    Messages msg = new Messages(message, time, senderId, receiverId, read);
                    list.add(msg);
                    seenMessage(senderId, receiver,key);
                    messageAdapter.addMessageSent(list);
                    messageAdapter.notifyDataSetChanged();
                    if (Objects.requireNonNull(recyclerView.getAdapter()).getItemCount() > 0) {
                        recyclerView.smoothScrollToPosition(recyclerView.getAdapter().getItemCount());
                    }

                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public static boolean isYesterday(long d) {
        return DateUtils.isToday(d + DateUtils.DAY_IN_MILLIS);
    }

    public static boolean isToday(long d) {
        return DateUtils.isToday(d);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        StaticInfo.UserCurrentChatFriendEmail = "";
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        ;

    }

    @Override
    protected void onStop() {
        super.onStop();
        if (reference != null && seenMessage != null) {
            reference.removeEventListener(seenMessage);
        }
        StaticInfo.UserCurrentChatFriendEmail = "";
    }

    private void sendMessage(String sender, String receiver, String message) {
        DatabaseReference refNotMess = FirebaseDatabase.getInstance().getReference(StaticInfo.NotificationEndPoint + "/" + receiver);
        DatabaseReference rootRef = database.getReference();
        rootRef.keepSynced(true);
        DatabaseReference reference = rootRef.child("Chats").child(sender).child(receiver);
        DatabaseReference key = reference.push();
        String pushID = key.getKey();
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("time", ServerValue.TIMESTAMP);
        hashMap.put("message", message);
        hashMap.put("read", false);
        hashMap.put("id", sender);
        hashMap.put("receiver", receiver);
        reference.child(pushID).setValue(hashMap);
        rootRef.child("Chats").child(receiver).child(sender).child(pushID).setValue(hashMap);
        refNotMess.push().setValue(hashMap);
    }

    private void addView(String text) {
        mBinding.send.whatsappEditView.setText("");
        sendMessage(senderId, receiver, text);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(PersonChatActivity.this, MessengerMain.class));
        animation.slideDown(this);
    }

}