package com.patrickarungari.tukenyahub.chatApp.Messenger;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.patrickarungari.tukenyahub.Activities.MainActivity;
import com.patrickarungari.tukenyahub.Modules.animation;
import com.patrickarungari.tukenyahub.R;
import com.patrickarungari.tukenyahub.chatApp.ui.main.SectionsPagerAdapter;

import com.patrickarungari.messenger.core.ChatManager;
import com.patrickarungari.messenger.ui.ChatUI;

import spencerstudios.com.bungeelib.Bungee;

public class MessengerMain extends AppCompatActivity {


    private static final String TAG = "Messenger_Main: ";
    private DatabaseReference lastOnlineRef;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messenger_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.title);
        setSupportActionBar(toolbar);
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);
        mAuth = FirebaseAuth.getInstance();
        ChatUI.getInstance().processRemoteNotification(getIntent());
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chat_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id =item.getItemId();
        // Handle item selection
        if (id == R.id.new_game) {
            mAuth.signOut();
            startActivity(new Intent(this, MainActivity.class));
            animation.slideDown(this);
            return true;
        }
        if (id == R.id.menu_profile) {
            startActivity(new Intent(this, ActivityProfile.class));

        }

        if (id == R.id.menu_addContacts) {
            startActivity(new Intent(this, AddContactActivity.class));
            return true;
        }

        if (id == R.id.menu_notification) {
            startActivity(new Intent(this, ActivityNotifications.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

   /* @Override
    protected void onStart() {
        super.onStart();
        /*startService(new Intent(this, AppService.class));
        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        // any time that connectionsRef's value is null (i.e. has no children) I am offline
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        assert firebaseUser != null;
        String uId = firebaseUser.getUid();
        // Stores the timestamp of my last disconnect (the last time I was seen online)
        lastOnlineRef = database.getReference("users").child(uId).child("lastSeen");
        lastOnlineRef.keepSynced(true);
        lastOnlineRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    if (dataSnapshot.getKey() != null) {
                        // When I disconnect, update the last time I was seen online
                        lastOnlineRef.onDisconnect().setValue(ServerValue.TIMESTAMP);
                    }
                }

            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w(TAG, "Listener was cancelled at .info/connected");
            }
        });
        final DatabaseReference connectedRef = database.getReference(".info/connected");
        connectedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                boolean connected = snapshot.getValue(Boolean.class);
                if (connected) {

                    // When I disconnect, update the last time I was seen online
                    lastOnlineRef.setValue("Online");
                    lastOnlineRef.onDisconnect().setValue(ServerValue.TIMESTAMP);
                } else {
                    lastOnlineRef.setValue(ServerValue.TIMESTAMP);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w(TAG, "Listener was cancelled at .info/connected");
            }
        });
    }*/

    @Override
    protected void onPostResume() {
        ChatManager.getInstance().getMyPresenceHandler().connect();
        super.onPostResume();
        //lastOnlineRef.setValue(ServerValue.TIMESTAMP);
    }

  /*  @Override
    protected void onStop() {
       // lastOnlineRef.setValue(ServerValue.TIMESTAMP);
        super.onStop();
    }*/

    @Override
    protected void onDestroy() {
        ChatManager.getInstance().getMyPresenceHandler().dispose();
        super.onDestroy();
        //lastOnlineRef.setValue(ServerValue.TIMESTAMP);
    }

    @Override
    public void onBackPressed() {
        //lastOnlineRef.setValue(ServerValue.TIMESTAMP);
        startActivity(new Intent(MessengerMain.this, MainActivity.class));
        Bungee.slideRight(this);
    }
}