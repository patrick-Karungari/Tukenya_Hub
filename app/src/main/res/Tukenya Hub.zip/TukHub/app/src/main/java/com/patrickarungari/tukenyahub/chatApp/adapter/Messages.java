package com.patrickarungari.tukenyahub.chatApp.adapter;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Messages {
    private String message;

    private long time;
    public int type;
    public boolean read;
    private String id;
    private String receiver;

    public boolean isRead() {
        return read;
    }

    public void setRead(boolean read) {
        this.read = read;
    }

    public Messages(String message, long time, String sender, String receiver, boolean read) {
        this.message = message;
        this.time = time;
        this.id = sender;
        this.read = read;
        //this.type = type;
        this.receiver = receiver;
    }

    public Messages() {
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getTime() {

        SimpleDateFormat output = new SimpleDateFormat("HH:mm", Locale.getDefault());
        return output.format(new Date(time));
    }

    public void setTime(long time) {
        this.time = time;
    }

    public String getSender() {
        return id;
    }

    public void setSender(String sender) {
        this.id = sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }
}
