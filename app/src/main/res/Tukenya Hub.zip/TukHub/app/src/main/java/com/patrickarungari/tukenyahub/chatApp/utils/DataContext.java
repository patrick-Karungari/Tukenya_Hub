package com.patrickarungari.tukenyahub.chatApp.utils;

import androidx.annotation.NonNull;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.patrickarungari.tukenyahub.chatApp.adapter.User;

public class DataContext {
    private static User user = new User();
    String id;

    public DataContext() {


    }

    public void deleteChat(String id) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference(StaticInfo.MessagesEndPoint);
        reference.keepSynced(true);
        reference.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(id).removeValue();
    }

    public void deleteFriend(String id) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference(StaticInfo.FriendsURL);
        reference.keepSynced(true);
        reference.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(id).removeValue();
    }

    public static User getFriendByEmail(String id) {

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("users");
        reference.keepSynced(true);
        reference.child(id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    if (dataSnapshot.getValue() != null) {
                        String name = (String) dataSnapshot.child("Name").getValue();
                        String num = (String) dataSnapshot.child("regNum").getValue();
                        String path = (String) dataSnapshot.child("imagePath").getValue();
                        String userId = (String) dataSnapshot.getKey();
                        user = new User(num, userId, path, name);

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        return user;
    }
}
