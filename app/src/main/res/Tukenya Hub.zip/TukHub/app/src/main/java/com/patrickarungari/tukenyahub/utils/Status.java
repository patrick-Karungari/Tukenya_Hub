package com.patrickarungari.tukenyahub.utils;


public enum Status {
    LOADING,
    SUCCESS,
    ERROR
}