package com.patrickarungari.tukenyahub.chatApp.adapter;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.patrickarungari.tukenyahub.R;

import java.util.ArrayList;


public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {
    public static final int MSG_TYPE_LEFT = 0;
    public static final int MSG_TYPE_RIGHT = 1;
    private static final int SENT_TYPE = 2;
    private static final int RECEIVED_TYPE = 3;
    FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();


    private Context ctx;
    private ArrayList<Messages> dataSet;

    public MessageAdapter(Context context) {
        this.ctx = context;
        this.dataSet = new ArrayList<>();
        //this.msgsR = messagesReceived;
    }


    @Override
    public MessageAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == SENT_TYPE) {
            View view = LayoutInflater.from(ctx).inflate(R.layout.message_item_right, parent, false);
            return new ViewHolder(view);
        }
        if (viewType == RECEIVED_TYPE) {
            View view = LayoutInflater.from(ctx).inflate(R.layout.message_item_left, parent, false);
            return new ViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull MessageAdapter.ViewHolder holder, int position) {
        Messages msg = dataSet.get(position);

        if (holder.read != null && msg.isRead()) {
            holder.read.setImageDrawable(ContextCompat.getDrawable(ctx, R.drawable.ic_double_tick_indicator));
        }
        if (holder.read != null && !msg.isRead()) {
            holder.read.setImageDrawable(ContextCompat.getDrawable(ctx, R.drawable.grey_tick));
        }


        holder.msg.setText(msg.getMessage());
        holder.msg.setPadding(6, 4, 22, 1);
        holder.msg.setMinWidth(100);
        holder.msg.setMaxWidth(400);
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) holder.msg.getLayoutParams();
        layoutParams.gravity = Gravity.START;
        layoutParams.width = LinearLayout.LayoutParams.WRAP_CONTENT;
        layoutParams.height = LinearLayout.LayoutParams.WRAP_CONTENT;
        layoutParams.topMargin = layoutParams.rightMargin = 10;
        layoutParams.leftMargin = 20;
        layoutParams.bottomMargin = 0;
        holder.msg.setLayoutParams(layoutParams);
        holder.time.setText(msg.getTime());
    }


    public void addMessageSent(ArrayList<Messages> messages) {
        // dataSet.clear();
        dataSet.addAll(messages);
        // notifyItemInserted(dataSet.size()-1);
        //notifyItemRangeChanged(dataSet.size()-1, dataSet.size());

    }

    public void clearAllMessage() {
        dataSet.clear();
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }


    @Override
    public int getItemViewType(int position) {

        if (dataSet.get(position).getSender().equals(firebaseUser.getUid())) {
            return SENT_TYPE;
        } else {
            return RECEIVED_TYPE;

        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView msg, time;
        public CardView layout;
        public ImageView read;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            read = itemView.findViewById(R.id.read);
            msg = itemView.findViewById(R.id.send_msg);
            time = itemView.findViewById(R.id.time);


        }
    }
}
