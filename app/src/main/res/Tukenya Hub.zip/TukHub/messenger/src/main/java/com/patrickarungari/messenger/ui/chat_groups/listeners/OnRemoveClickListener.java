package com.patrickarungari.messenger.ui.chat_groups.listeners;

/**
 * Created by stefanodp91 on 17/01/17.
 */

public interface OnRemoveClickListener {
    void onRemoveClickListener(int position);
}
